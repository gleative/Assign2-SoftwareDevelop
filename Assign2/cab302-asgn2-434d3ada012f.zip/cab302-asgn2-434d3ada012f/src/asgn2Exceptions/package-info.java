
/**
 * This package contains classes to represent different types of exceptions. You do not need to modify or test any of the classes in this package. 
 * @author Alan Woodley
 *
 */
package asgn2Exceptions;