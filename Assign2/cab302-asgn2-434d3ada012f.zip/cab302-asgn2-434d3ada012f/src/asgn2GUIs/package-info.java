/**
 * This package contains the GUI which can be used to interact with the rest of the system. 
 * 
 * @author Person A and Person B
 *
 */
package asgn2GUIs;