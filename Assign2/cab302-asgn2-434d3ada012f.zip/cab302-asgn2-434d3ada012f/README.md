All information relating to Assignment 2 can be found on Blackboard
